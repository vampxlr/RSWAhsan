			
<?php include(TEMPLATEPATH . '/includes/scripts.php'); ?>

<?php wp_footer(); ?>	
</body>
</html>